//
//  SimpleVC2.swift
//  wellwellwell3
//
//  Created by LYM on 02/09/2019.
//  Copyright © 2019 LYM. All rights reserved.
//

import UIKit
import Charts
class SimpleVC2: UIViewController {
    let defaults = UserDefaults.standard
    var chartView: BarChartView!
    let groupCount = 4
    let weeks = ["Week1", "Week2", "Week3", "This Week"]
    let barWidth = 0.33
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setChart()
        defaults.synchronize()
        let label = UILabel(frame: CGRect(x: 40, y: 0, width: 400, height: 40))
        
        label.font = UIFont(name: "Halvetica", size: 50)
        label.center = CGPoint(x: 190, y: 320)
        label.textAlignment = .center
        label.text = "Wellbeing Mindful Minutes So Far"
        self.view.addSubview(label)
    }
    
    func setChart(){
        var mindfulMin = defaults.array(forKey: "mindful") as?[Int] ?? [Int]()
        chartView = BarChartView()
        chartView.frame = CGRect(x: 20, y: 350, width: 330,
                                 height: 350)
        
        self.view.addSubview(chartView)
        // 1st data
        var dataEntries3: [BarChartDataEntry] = []
        for i in 0..<groupCount {
            
            let entry = BarChartDataEntry(x: Double(i), y: Double(mindfulMin[i]))
            dataEntries3.append(entry)
        }
        
        
        let chartDataSet3 = BarChartDataSet(entries: dataEntries3, label:"Mindful Minutes")
        chartDataSet3.axisDependency = .left
        chartDataSet3.valueFormatter = DefaultValueFormatter(decimals: 0)
        let chartData = BarChartData(dataSets: [chartDataSet3])
        chartData.barWidth = barWidth
        
        
        chartView.xAxis.axisMinimum = Double(-0.55)
        
        chartView.xAxis.centerAxisLabelsEnabled = false
        chartView.xAxis.granularity = 1
        chartView.xAxis.granularityEnabled = true
        
        chartView.xAxis.labelPosition = .bottom
        
        chartView.xAxis.valueFormatter = IndexAxisValueFormatter(values:self.weeks)
        chartView.xAxis.avoidFirstLastClippingEnabled = false
        chartView.leftAxis.axisMinimum = 0.0
        chartView.rightAxis.axisMinimum = 0.0
        chartView.xAxis.drawGridLinesEnabled = false
        chartView.leftAxis.drawGridLinesEnabled = false
        chartView.rightAxis.drawGridLinesEnabled = false
        chartView.rightAxis.enabled = false
        chartView.doubleTapToZoomEnabled = false
        chartView.data = chartData
    }
    
    
    
}
