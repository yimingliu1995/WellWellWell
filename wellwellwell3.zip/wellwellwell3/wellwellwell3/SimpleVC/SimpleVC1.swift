//
//  SimpleVC1.swift
//  wellwellwell3
//
//  Created by LYM on 02/09/2019.
//  Copyright © 2019 LYM. All rights reserved.
//

import Charts
import UIKit

class SimpleVC1: UIViewController {
    var chartView: BarChartView!
    let defaults = UserDefaults.standard
    let groupSpace = 0.4
    let barSpace = 0.05
    let barWidth = 0.25
    let groupCount = 4
    let weeks = ["Week1", "Week2", "Week3", "This Week"]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setChart()
        
        let label = UILabel(frame: CGRect(x: 40, y: 0, width: 400, height: 40))
        
        label.font = UIFont(name: "Halvetica", size: 50)
        label.center = CGPoint(x: 190, y: 320)
        label.textAlignment = .center
        label.text = "Steps and Distances travelled Last 4 Weeks"
        
        self.view.addSubview(label)
        
        
    }
    
    
    func setChart(){
        
        var steps = defaults.array(forKey: "steps")  as? [Int] ?? [Int]()
        
        chartView =  BarChartView()
        chartView.frame = CGRect(x: 20, y: 350, width: 330,
                                 height: 350)
        self.view.addSubview(chartView)
        
        // 1st data
        var dataEntries1: [BarChartDataEntry] = []
        
        for i in 0..<groupCount {
            
            let entry = BarChartDataEntry(x: Double(i), y: Double(steps[i]))
            dataEntries1.append(entry)
        }
        
        
        let chartDataSet1 = BarChartDataSet(entries: dataEntries1, label:"Steps")
        chartDataSet1.axisDependency = .left
        // 2nd data
        var distance = defaults.array(forKey: "distances")as? [Float] ?? [Float]()
        var dataEntries2: [BarChartDataEntry] = []
        for i in 0..<groupCount {
            
            let dataEntry = BarChartDataEntry(x: Double(i), y: Double(distance[i]))
            dataEntries2.append(dataEntry)
        }
        let chartDataSet2 = BarChartDataSet(entries: dataEntries2, label:"Distance (km)")
        chartDataSet2.axisDependency = .right
        chartDataSet2.colors = [.orange]
        chartDataSet2.valueFormatter = DefaultValueFormatter(decimals: 0)
        
        let chartData = BarChartData(dataSets: [chartDataSet1, chartDataSet2])
        chartData.barWidth = barWidth
        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        chartView.xAxis.axisMinimum = Double(0.0)
        chartView.xAxis.axisMaximum = Double(0.0) + chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * Double(groupCount)
        chartView.xAxis.centerAxisLabelsEnabled = true
        chartView.xAxis.granularity = 1.0
        chartView.xAxis.granularityEnabled = true
        
        chartView.xAxis.labelPosition = .bottom
        
        chartView.xAxis.valueFormatter = IndexAxisValueFormatter(values:self.weeks)
        chartView.xAxis.avoidFirstLastClippingEnabled = false
        chartView.leftAxis.axisMinimum = 0.0
        chartView.rightAxis.axisMinimum = 0.0
        chartView.xAxis.drawGridLinesEnabled = false
        chartView.leftAxis.drawGridLinesEnabled = false
        chartView.rightAxis.drawGridLinesEnabled = false
        chartView.rightAxis.enabled = true
        chartView.doubleTapToZoomEnabled = false
        chartView.data = chartData
        
        
        
    }
    
    
}

