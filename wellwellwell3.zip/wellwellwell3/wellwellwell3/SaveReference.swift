//
//  SaveReference.swiftSettingsController
//  wellwellwell3
//
//  Created by LYM on 21/08/2019.
//  Copyright © 2019 LYM. All rights reserved.
//

import UIKit

class saveController : UIViewController {
    let defaults = UserDefaults.standard
    
    
    @IBOutlet weak var refer1: UITextField!
    
    
    @IBOutlet weak var refer2: UITextField!
    
    
    @IBOutlet weak var postcode: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkForSavedText()
    refer1.delegate = self
    refer2.delegate = self
    postcode.delegate = self
       
    }
    
    func saveText() {
        defaults.set(refer1.text!, forKey: "refer1")
        defaults.set(refer2.text!, forKey: "refer2")
        defaults.set(postcode.text!, forKey: "postcode")
        defaults.synchronize()
    }
    
    func checkForSavedText(){
        let text1 = defaults.string(forKey: "refer1")
        refer1.text = text1
        let text2 = defaults.string(forKey: "refer2")
        refer2.text = text2
        let text3 = defaults.string(forKey: "postcode")
        postcode.text = text3
    }
    
    @IBAction func saveDetails(_ sender: Any) {
        saveText()
        displaySaveAlertMessage()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        refer1.resignFirstResponder()
    }
    
    func displaySaveAlertMessage(){
        
        let myAlert = UIAlertController(title: "Congratulations", message: "\n You have successfully saved your reference and postcode \n", preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
    }
}

extension saveController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
