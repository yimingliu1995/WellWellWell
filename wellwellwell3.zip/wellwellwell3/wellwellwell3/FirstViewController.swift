//
//  FirstViewController.swift
//  wellwellwell3
//
//  Created by LYM on 04/07/2019.
//  Copyright © 2019 LYM. All rights reserved.
//

import UIKit
import Foundation
import CoreML
import HealthKit



class FirstViewController: UIViewController, UITextFieldDelegate {
//    let vc = saveController()
//    let scorePred = pre()
   
    let model = wellML()
    let healthStore = HKHealthStore()
    let vc2 = SecondViewController()
    let defaults = UserDefaults.standard
    let stepstest = (UserDefaults.standard.double(forKey: "This Week"))
    
    let mindfultest = UserDefaults.standard.double(forKey: "mindful This Week")
    let wifiSenttest = UserDefaults.standard.double(forKey: "wifiSent")
    let wifiReceivedtest = UserDefaults.standard.double(forKey: "wifiReceived")

//    let sc = SecondViewController()
    // var
    var isPlaying: Bool = false
  
    
    @IBOutlet weak var output: UILabel!
    @IBOutlet weak var start: UIButton!
    
    @IBOutlet weak var scorevalue: UILabel!
    

    @IBAction func checkRef(_ sender: Any) {
        if defaults.string(forKey: "refer1")?.isEmpty ?? true
            || defaults.string(forKey: "refer2")?.isEmpty ?? true || defaults.string(forKey: "postcode")?.isEmpty ?? true {
            displayMyAlertMessage(userMessage: "Please fill in reference and postcode", Title: "ERROR")
        }
    }
    
    @IBAction func showPopUp(_ sender: Any) {
        let popOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "sbPopUpID") as! PopUpViewController
        self.addChild(popOverVC)
        popOverVC.view.frame = self.view.frame
        self.view.addSubview(popOverVC.view)
        popOverVC.didMove(toParent: self)
    }
    @IBAction func url(_ sender: UIButton) {
        UIApplication.shared.open(URL(string:"https://www.nhs.uk/conditions/stress-anxiety-depression/improve-mental-wellbeing/") as! URL, options: [:], completionHandler: nil)
    }
    @IBAction func `switch`(_ sender: UISwitch)
    // Actions can be added here to bind connection between previous framework
    {
    if (sender.isOn == true)
    { output.text = "Enable anonymous data sharing"
    }
    else
    { output.text = "Disable anonymous data sharing"
    }
    
}
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let readType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)!
        healthStore.requestAuthorization(toShare: [], read: [readType]) { _, _ in }
        
        let Readtype = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.distanceWalkingRunning)!
        healthStore.requestAuthorization(toShare: [], read: [Readtype]) { _, _ in }
        self.applyRoundCorner(start)
        
            }
    func applyRoundCorner(_ object:AnyObject){
        object.layer.cornerRadius = object.frame.size.width / 2
        object.layer.masksToBounds = true
    }
    // set alert of reference confirmation
    func displayMyAlertMessage(userMessage:String, Title: String){
        
        let myAlert = UIAlertController(title: Title, message: userMessage, preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
    }
    // set alert to display score predicted
    func displayScoreAlertMessage(userMessage:String){
        let myAlert = UIAlertController(title: "Your Score This Week is:", message: userMessage, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default){
            UIAlertAction in
            self.otheralert(userMessage: "Do you want to view suggestions to improve your well being score? \n")}
        let NoAction = UIAlertAction(title: "No", style: UIAlertAction.Style.default){
            UIAlertAction in
            self.showInputDialog()
        }
        myAlert.addAction(okAction)
        myAlert.addAction(NoAction)
        
        
        self.present(myAlert, animated: true){
            myAlert.view.superview?.subviews[0].isUserInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.dismissAlertController))
            myAlert.view.superview?.subviews[0].addGestureRecognizer(tapGesture)
        }
    }
    
    @objc func dismissAlertController(){
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func validation(_ sender: Any) {
        if defaults.string(forKey: "refer1")?.isEmpty ?? true
            || defaults.string(forKey: "refer2")?.isEmpty ?? true || defaults.string(forKey: "postcode")?.isEmpty ?? true {
           
            displayMyAlertMessage(userMessage: "\n Please fill in reference and postcode \n", Title: "ERROR")
        
        }
       
    }
    // set alert of asking user whether they need hints or not
    func otheralert(userMessage:String){
        let myAlert = UIAlertController(title: "Hint! ", message: userMessage, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default){
            UIAlertAction in
            self.suggestions1()
            
        }
        let NoAction = UIAlertAction(title: "No", style: UIAlertAction.Style.default, handler: nil)
        myAlert.addAction(okAction)
        myAlert.addAction(NoAction)
        
        self.present(myAlert, animated: true, completion: nil)
        
    }
    // set alert of editing suggestions
    func secondalert(userMessage: String){
        let myAlert = UIAlertController(title: "Suggestions! ", message: userMessage, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction)
        
        
        self.present(myAlert, animated: true, completion: nil)
    }
    //set alert of confirmation of save score successfully
    func thirdalert(){
        let alertController = UIAlertController(title: "Congratulations", message: "\n The score you input has been stored and will be displayed in the pdf file", preferredStyle: UIAlertController.Style.alert)
        // can be edited further
       
        let cancelAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)

        alertController.addAction(cancelAction)

        self.present(alertController, animated: true, completion: nil)
    }
    // set keyboard only accept number between 0 -10
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let newText = (textField.text! as NSString).replacingCharacters(in: range, with: string) as String
        if let num = Int(newText), num >= 0 && num <= 10 {
            return true
        }else{
        return false
    }
    
    }
        
   
    // set alert of asking user to input score manually
    
   func showInputDialog(title:String? = "Input Score",
                              subtitle:String? = "\n Please input what you think your score should be!! \n If you want to delete, press clear button in the textField!",
                              actionTitle:String? = "Update",
                              cancelTitle:String? = "Cancel",
                              inputPlaceholder:String? = "Please input integer (0 - 10)! ",
                              inputKeyboardType:UIKeyboardType = UIKeyboardType.asciiCapableNumberPad,
                              cancelHandler: ((UIAlertAction) -> Swift.Void)? = nil,
                              actionHandler: ((_ text: String?) -> Void)? = nil) {
        
        let alert = UIAlertController(title: title, message: subtitle, preferredStyle: .alert)
        alert.addTextField { (numberField:UITextField) in
            numberField.placeholder = inputPlaceholder
            numberField.keyboardType = inputKeyboardType
            numberField.clearButtonMode = UITextField.ViewMode.always
            numberField.delegate = self
        }
        alert.addAction(UIAlertAction(title: actionTitle, style: .default, handler: { (action) in
            let input = alert.textFields![0]

            self.defaults.set(input.text, forKey: "New score")
            self.defaults.synchronize()
            self.thirdalert()
        }))
        alert.addAction(UIAlertAction(title: cancelTitle, style: .cancel, handler: cancelHandler))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func suggestions1(){
        
        if stepstest < 50000.0 {
            if mindfultest < 100.0{
                secondalert(userMessage: "\n You probably need to exercise more and spend more time relaxing your mind!")
            }
            else if mindfultest > 100.0 && mindfultest < 500.0 {
                secondalert(userMessage: "\n You probably need to exercise more!")
            }
            else if mindfultest > 500.0{
                secondalert(userMessage: "\n You probably need to exercise more and spend more time communicating with others!")
            }
        }
        else if stepstest > 50000.0 && stepstest < 99999.0{
            if mindfultest < 100.0{
                secondalert(userMessage: "\n Good Job! What you need to do is to spend more time relaxing your mind!")
            }
            else if mindfultest > 100.0 && mindfultest < 300.0 {
                secondalert(userMessage: "\n Good Job! Keep it!")
            }
            else if mindfultest > 300.0{
                secondalert(userMessage: "\n Good Job! However, you probably need to spend more time communicating with others!")
            }
        }
        else {
            secondalert(userMessage: "\n You are walking like a sportsman! Probably need to take more time relaxing your mind and communicating with others")
        }
    }
   
    
    var button1: UIButton!
    @IBAction func btnStartStop(_ sender: UIButton) {
        let longString = "\n \(defaults.integer(forKey: "lastscore")) \n \n Do you think this is correct? \n (You can tap outside of the alert to exit if you do not want to make your choice now)"
        
        if isPlaying{
            isPlaying = false
            sender.setTitle("STOP TRACKING", for: .normal
            )

           predict()
            displayScoreAlertMessage(userMessage: longString)
            scorevalue.isHidden = false

            print(self.stepstest)
            
          
    }
        else{
            isPlaying = true
            sender.setTitle("START TRACKING", for: .normal
            )
          scorevalue.isHidden = true
        }
    }
    
   

    
    func predict(){

  
                if let predictions = try?

                    self.model.prediction(steps: stepstest, mindful: mindfultest, wifiReceived: wifiReceivedtest, wifiSent: wifiSenttest){
                    print(predictions.score)

                    let ps = Int(predictions.score)
                        scorevalue.text = "\(ps)"
                        self.defaults.set(ps, forKey: "lastscore")
                    self.defaults.synchronize()

                    
                }
                else{
                    print("Error")
                }

            }

    @objc func butonAction(sender:UIButton!){
        print("Button tapped")
    }

}
