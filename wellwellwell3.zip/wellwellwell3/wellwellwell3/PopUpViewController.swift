//
//  PopUpViewController.swift
//  wellwellwell3
//
//  Created by LYM on 11/07/2019.
//  Copyright © 2019 LYM. All rights reserved.
//

import UIKit

class PopUpViewController: UIViewController {
    override func viewDidLoad(){
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
    }
    
    @IBAction func closePopUp(_ sender: AnyObject) {
        self.view.removeFromSuperview()
    }
    


}
