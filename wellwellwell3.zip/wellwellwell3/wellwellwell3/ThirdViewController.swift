//
//  ThirdViewController.swift
//  wellwellwell3
//
//  Created by LYM on 18/07/2019.
//  Copyright © 2019 LYM. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    var Steps = [Int]()
    var distance = [Float]()
    var mindful = [Int]()
    let defaults = UserDefaults.standard
    
    @IBOutlet weak var viewcontainer: UIView!
    var views: [UIView]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Steps.append(defaults.integer(forKey: "LastThree Week"))
        Steps.append(defaults.integer(forKey: "LastTwo Week"))
        Steps.append(defaults.integer(forKey: "Last Week"))
        Steps.append(defaults.integer(forKey: "This Week"))
        defaults.set(Steps, forKey: "steps")
        defaults.synchronize()
        distance.append(defaults.float(forKey: "Distance LastThree Week"))
        distance.append(defaults.float(forKey: "Distance LastTwo Week"))
        distance.append(defaults.float(forKey: "Distance Last Week"))
        distance.append(defaults.float(forKey: "Distance This Week"))
        
        defaults.set(distance, forKey: "distances")
        defaults.synchronize()
        
        mindful.append(defaults.integer(forKey: "mindful LastThree Week"))
        mindful.append(defaults.integer(forKey: "mindful LastTwo Week"))
        mindful.append(defaults.integer(forKey: "mindful Last Week"))
        mindful.append(defaults.integer(forKey: "mindful This Week"))
        defaults.set(mindful, forKey: "mindful")
        defaults.synchronize()
        
        views = [UIView]()
        views.append(SimpleVC1().view)
        views.append(SimpleVC2().view)
        
        
        for v in views {
            viewcontainer.addSubview(v)
        }
        viewcontainer.bringSubviewToFront(views[0])
  }
    
    func displayMyAlertMessage(userMessage:String, Title: String){
        
        let myAlert = UIAlertController(title: Title, message: userMessage, preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
    }
    @IBAction func Hint(_ sender: Any) {
          displayMyAlertMessage(userMessage: "\n The charts will automatically update every time you first enter this page! However, it's better to close the app completely if you want to update data mannualy by HealthKit!\n", Title: "Hint")
       
    }
   
    
    @IBAction func switchviewaction(_ sender: UISegmentedControl) {
        self.viewcontainer.bringSubviewToFront(views[sender.selectedSegmentIndex])
        
    }
}
