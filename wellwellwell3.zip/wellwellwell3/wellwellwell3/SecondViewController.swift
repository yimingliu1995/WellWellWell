//
//  SecondViewController.swift
//  wellwellwell3
//
//  Created by LYM on 04/07/2019.
//  Copyright © 2019 LYM. All rights reserved.
//

import UIKit
import HealthKit

class SecondViewController: UIViewController {
let sc = ShareController()

    let startDate = Date().startOfWeek
    let endDate = Date().endOfWeek
    @IBOutlet weak var wifiSentLabel: UILabel!
    
    @IBOutlet weak var wifiReceivedLabel: UILabel!

    
 
    @IBOutlet weak var meditationMinutesLabel: UILabel!
    @IBOutlet weak var distanceCountLabel: UILabel!
    @IBOutlet weak var stepsCountLabel: UILabel!
    @IBOutlet weak var steps: UIImageView!
    
    @IBOutlet weak var messages: UIImageView!
    
    @IBOutlet weak var foots: UIImageView!
    
    
    @IBOutlet weak var browse: UIImageView!
    @IBOutlet weak var social: UIImageView!


    

    let defaults = UserDefaults.standard
    let healthStore = HKHealthStore()
    // MARK:- Private Properties
    private var timer: DispatchSourceTimer?
    var Steps = [Int]()
    var distance = [Float]()
   var mindful = [Int]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.activateHealthKit()
        
       foots.loadGif(name: "foot")
       steps.loadGif(name: "walkinggif")
        messages.loadGif(name: "textmessagegif")
        
        social.loadGif(name: "socialmediagif")
        browse.loadGif(name: "earth")
        
        
        if DeviceManager.rebootOccuredFromLastTime {
            // New reboot detected
            // Store data usage of last session with data usage of all session
            let lastSessionDataUsage = DataUsage.lastSessionDataUsageInfoFromDatabase
            DataUsage.saveTotal(dataUsageInfo: lastSessionDataUsage)
        }
        startTimer()

    }
    
    deinit {
        self.stopTimer()
    }
    
    // MARK:- Private Functions
    private func startTimer() {
        let queue = DispatchQueue(label: "com.domain.app.timer")  // you can also use `DispatchQueue.main`, if you want
        timer = DispatchSource.makeTimerSource(queue: queue)
        timer!.schedule(deadline: .now(), repeating: .seconds(30))
        timer!.setEventHandler { [weak self] in
            // do whatever you want here
            self?.periodicUpdateDatabase()
        }
        timer!.resume()
    }
    
    private func periodicUpdateDatabase() {
        let currentDataUsageInfo = DataUsage.currentSessionDataUsageInfo
        DataUsage.saveCurrent(dataUsageInfo: currentDataUsageInfo)
        updateLabels()
    }
    
    private func updateLabels() {
        let dataUsageInfo = DataUsage.allSessionsDataUsageInfo
        
        updateLabels(with: dataUsageInfo)
    }
    
    private func updateLabels(with dataUsageInfo: DataUsageInfo) {
        let wifiSentInMB = dataUsageInfo.wifiSent
        let wifiReceivedInMB = dataUsageInfo.wifiReceived
        
        DispatchQueue.main.async {
            self.wifiSentLabel.text = wifiSentInMB.toMegabytesString
            self.wifiReceivedLabel.text = wifiReceivedInMB.toMegabytesString
          self.defaults.set(wifiSentInMB.toMegabytesString, forKey: "wifiSent")
          self.defaults.set(wifiReceivedInMB.toMegabytesString, forKey: "wifiReceived")
            self.defaults.synchronize()
        }
    }
    private func stopTimer() {
        timer?.cancel()
        timer = nil
    }
    func activateHealthKit() {
        // Define what HealthKit data we want to ask to read
        let typestoRead = Set([
            HKObjectType.categoryType(forIdentifier: HKCategoryTypeIdentifier.mindfulSession)!
            ])

        // Prompt the User for HealthKit Authorization
        self.healthStore.requestAuthorization(toShare: [], read: typestoRead) { _, _ in }
        self.retrieveMindFulMinutes()
        
        

        
    }
    
    //Steps
    func getCountStepUsingStatisticsQuery(from start: Date, to end: Date, completion handler: @escaping (HKStatisticsQuery, HKStatistics?, Error?) -> Void) {
        let type = HKSampleType.quantityType(forIdentifier: .stepCount)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        
        let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum, completionHandler: handler)
        healthStore.execute(query)
    }
    //Distances
    func getDistanceUsingStatisticsQuery(from start: Date, to end: Date, completion handler: @escaping (HKStatisticsQuery, HKStatistics?, Error?) -> Void) {
        let Type = HKSampleType.quantityType(forIdentifier: .distanceWalkingRunning)!
        let Predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        
        let Query = HKStatisticsQuery(quantityType: Type, quantitySamplePredicate: Predicate, options: .cumulativeSum, completionHandler: handler)
        healthStore.execute(Query)
    }
    
// mindful mintues this week
    func retrieveMindFulMinutes() {
        let type = HKSampleType.categoryType(forIdentifier: .mindfulSession)!
        let startDate = Date().startOfWeek
        let endDate = Date().endOfWeek
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate)
        
        let query = HKSampleQuery(
            sampleType: type,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: [sortDescriptor],
            resultsHandler: updateMeditationTime
        )
    
        healthStore.execute(query)
    
    }
        func calculateTotalTime(sample: HKSample) -> TimeInterval {
        let totalTime = sample.endDate.timeIntervalSince(sample.startDate)
        let wasUserEntered = sample.metadata?[HKMetadataKeyWasUserEntered] as? Bool ?? false

        print("\nHealthkit mindful entry: \(sample.startDate) \(sample.endDate) - value: \(totalTime) quantity: \(totalTime) user entered: \(wasUserEntered)\n")

        return totalTime
    }
//update mindful mins this week
    func updateMeditationTime(query: HKSampleQuery, results: [HKSample]?, error: Error?) {
        if error != nil {return}

        // Sum the meditation time
        let totalMeditationTime = results?.map(calculateTotalTime).reduce(0, { $0 + $1 }) ?? 0
        let minutes = Int(totalMeditationTime / 60)
        
        DispatchQueue.main.async {
            self.meditationMinutesLabel.text = "\(minutes)"
            self.defaults.set(minutes, forKey: "mindful This Week")
            self.defaults.synchronize()
        }
    }
    
    //mindful minutes last week
    func retrieveMindFulMinutesLastWeek() {
        let type = HKSampleType.categoryType(forIdentifier: .mindfulSession)!
        let startDate = Date().startOfLastWeek
        let endDate = Date().endOfLastWeek
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate)
        
        let query = HKSampleQuery(
            sampleType: type,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: [sortDescriptor],
            resultsHandler: updateMeditationTimeLastWeek
        )
        
        healthStore.execute(query)
        
    }

    //update mindful mins last week
    func updateMeditationTimeLastWeek(query: HKSampleQuery, results: [HKSample]?, error: Error?) {
        if error != nil {return}
        
        // Sum the meditation time
        let totalMeditationTime = results?.map(calculateTotalTime).reduce(0, { $0 + $1 }) ?? 0
        let minutes = Int(totalMeditationTime / 60)
        
        DispatchQueue.main.async {
            self.defaults.set(minutes, forKey: "mindful Last Week")
            self.defaults.synchronize()
        }
    }
    
    //mindful minutes last Two week
    func retrieveMindFulMinutesLastTwoWeek() {
        let type = HKSampleType.categoryType(forIdentifier: .mindfulSession)!
        let startDate = Date().startOfLastTwoWeek
        let endDate = Date().endOfLastTwoWeek
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate)
        
        let query = HKSampleQuery(
            sampleType: type,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: [sortDescriptor],
            resultsHandler: updateMeditationTimeLastTwoWeek
        )
        
        healthStore.execute(query)
        
    }
    
    //update mindful mins last Two week
    func updateMeditationTimeLastTwoWeek(query: HKSampleQuery, results: [HKSample]?, error: Error?) {
        if error != nil {return}
        
        // Sum the meditation time
        let totalMeditationTime = results?.map(calculateTotalTime).reduce(0, { $0 + $1 }) ?? 0
        let minutes = Int(totalMeditationTime / 60)
        
        DispatchQueue.main.async {
            self.defaults.set(minutes, forKey: "mindful LastTwo Week")
            self.defaults.synchronize()
        }
    }
    //mindful minutes last Three week
    func retrieveMindFulMinutesLastThreeWeek() {
        let type = HKSampleType.categoryType(forIdentifier: .mindfulSession)!
        let startDate = Date().startOfLastThreeWeek
        let endDate = Date().endOfLastThreeWeek
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate)
        
        let query = HKSampleQuery(
            sampleType: type,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: [sortDescriptor],
            resultsHandler: updateMeditationTimeLastThreeWeek
        )
        
        healthStore.execute(query)
        
    }
    
    //update mindful mins lastThree week
    func updateMeditationTimeLastThreeWeek(query: HKSampleQuery, results: [HKSample]?, error: Error?) {
        if error != nil {return}
        
        // Sum the meditation time
        let totalMeditationTime = results?.map(calculateTotalTime).reduce(0, { $0 + $1 }) ?? 0
        let minutes = Int(totalMeditationTime / 60)
        
        DispatchQueue.main.async {
            self.defaults.set(minutes, forKey: "mindful LastThree Week")
            self.defaults.synchronize()
        }
    }

  
   

    
    
    //update steps
     func updateStepLabel(start: Date, end: Date) {
        
          getCountStepUsingStatisticsQuery(from: start, to: end) { (query, statistics, error) in
          DispatchQueue.main.async {
          if let value = statistics?.sumQuantity()?.doubleValue(for: .count()) {
          self.stepsCountLabel.text = "\(Int(value))"
            
           self.defaults.set(value, forKey: "This Week")
            self.defaults.synchronize()

          } else {
          self.stepsCountLabel.text = "0"
         }
      }
     }
    }
    //update distances
     func updateDistanceLabel(start: Date, end: Date) {
        getDistanceUsingStatisticsQuery(from: start, to: end) { (Query, statistics, error) in
            DispatchQueue.main.async {
                let km = HKUnit.meterUnit(with: .kilo)
                if let Value = statistics?.sumQuantity()?.doubleValue(for: km ){
                    self.distanceCountLabel.text = "\((Value * 100).rounded()/100)"
                    self.defaults.set((Value * 100).rounded()/100, forKey: "Distance This Week")
                    self.defaults.synchronize()
                } else {
                    self.distanceCountLabel.text = "0"
                }
            }
        }
    }
  // steps last week
    func stepsLastWeek(start: Date, end: Date){
        getCountStepUsingStatisticsQuery(from: start, to: end) { (query, statistics, error) in
            DispatchQueue.main.async {
                if let value = statistics?.sumQuantity()?.doubleValue(for: .count()) {
                    
                    self.defaults.set(Int(value), forKey: "Last Week")
                    self.defaults.synchronize()
                
                }
            }
        }
    }
    
    // distance last week
    func updateDistanceLabelLastWeek(start: Date, end: Date) {
        getDistanceUsingStatisticsQuery(from: start, to: end) { (Query, statistics, error) in
            DispatchQueue.main.async {
                let km = HKUnit.meterUnit(with: .kilo)
                if let Value = statistics?.sumQuantity()?.doubleValue(for: km ){
                   
                    self.defaults.set((Value * 100).rounded()/100, forKey: "Distance Last Week")
                    self.defaults.synchronize()
                }
                
            }
        }
    }
    
    // steps last two week
    
    func stepsLastTwoWeek(start: Date, end: Date){
        getCountStepUsingStatisticsQuery(from: start, to: end) { (query, statistics, error) in
            DispatchQueue.main.async {
                if let value = statistics?.sumQuantity()?.doubleValue(for: .count()) {
                    
                    self.defaults.set(Int(value), forKey: "LastTwo Week")
                    self.defaults.synchronize()
                    
                }
            }
        }
    }
    // distance last two week
    
    func updateDistanceLabelLastTwoWeek(start: Date, end: Date) {
        getDistanceUsingStatisticsQuery(from: start, to: end) { (Query, statistics, error) in
            DispatchQueue.main.async {
                let km = HKUnit.meterUnit(with: .kilo)
                if let Value = statistics?.sumQuantity()?.doubleValue(for: km ){
                    
                    self.defaults.set((Value * 100).rounded()/100, forKey: "Distance LastTwo Week")
                    self.defaults.synchronize()
                }
                
            }
        }
    }
    
// steps last three week
    
    func stepsLastThreeWeek(start: Date, end: Date){
        getCountStepUsingStatisticsQuery(from: start, to: end) { (query, statistics, error) in
            DispatchQueue.main.async {
                if let value = statistics?.sumQuantity()?.doubleValue(for: .count()) {
                    
                    self.defaults.set(Int(value), forKey: "LastThree Week")
                    self.defaults.synchronize()
                    
                }
            }
        }
    }
    // distance last three week
    func updateDistanceLabelLastThreeWeek(start: Date, end: Date) {
        getDistanceUsingStatisticsQuery(from: start, to: end) { (Query, statistics, error) in
            DispatchQueue.main.async {
                let km = HKUnit.meterUnit(with: .kilo)
                if let Value = statistics?.sumQuantity()?.doubleValue(for: km ){
                    
                    self.defaults.set((Value * 100).rounded()/100, forKey: "Distance LastThree Week")
                    self.defaults.synchronize()
                }
                
            }
        }
    }
    // alert
    func displayMyAlertMessage(userMessage:String, Title: String){
        
        let myAlert = UIAlertController(title: Title, message: userMessage, preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil)
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
    }


   
    


    @IBAction func updatesteps(_ sender: UIButton) {
        
        let startDate = Date().startOfWeek
        let endDate = Date().endOfWeek
        let startDateLastWeek = Date().startOfLastWeek
        let endDateLastWeek = Date().endOfLastWeek
        let startDateLastTwoWeek = Date().startOfLastTwoWeek
        let endDateLastTwoWeek = Date().endOfLastTwoWeek
        let startDateLastThreeWeek = Date().startOfLastThreeWeek
        let endDateLastThreeWeek = Date().endOfLastThreeWeek
      
        
        updateStepLabel(start: startDate, end: endDate)
        stepsLastWeek(start: startDateLastWeek, end: endDateLastWeek)
        stepsLastTwoWeek(start: startDateLastTwoWeek, end: endDateLastTwoWeek)
        stepsLastThreeWeek(start: startDateLastThreeWeek, end: endDateLastThreeWeek)
        updateLabels()
        
        updateDistanceLabel(start: startDate, end: endDate)
        
        updateDistanceLabelLastWeek(start: startDateLastWeek, end: endDateLastWeek)
        updateDistanceLabelLastTwoWeek(start: startDateLastTwoWeek, end: endDateLastTwoWeek)
     updateDistanceLabelLastThreeWeek(start: startDateLastThreeWeek, end: endDateLastThreeWeek)
        retrieveMindFulMinutes()
       retrieveMindFulMinutesLastWeek()
        retrieveMindFulMinutesLastTwoWeek()
        retrieveMindFulMinutesLastThreeWeek()
        
    }

}

private extension UInt64 {
    var toMegabytesString: String {
        let byteCountFormatter = ByteCountFormatter()
        byteCountFormatter.allowedUnits = [.useMB]
        byteCountFormatter.countStyle = .binary
        let megabytesString = byteCountFormatter.string(fromByteCount: Int64(self))
        return megabytesString
    }
}


    
    extension Date {
        var startOfWeek:  Date {
            let gregorian = Calendar(identifier: .gregorian)
            let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self))
            return gregorian.date(byAdding: .day, value: gregorian.firstWeekday, to: sunday!)!
        }

        var endOfWeek: Date {
            let gregorian = Calendar(identifier: .gregorian)
            let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self))
            return gregorian.date(byAdding: .day, value: 8, to: sunday!)!
        }
        
        var startOfLastWeek:  Date {
            let gregorian = Calendar(identifier: .gregorian)
            let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self))
            return gregorian.date(byAdding: .day, value: -6, to: sunday!)!
        }
        
        var endOfLastWeek: Date {
            let gregorian = Calendar(identifier: .gregorian)
            let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self))
            return gregorian.date(byAdding: .day, value: 1, to: sunday!)!
        }
        
        var startOfLastTwoWeek:  Date {
            let gregorian = Calendar(identifier: .gregorian)
            let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self))
            return gregorian.date(byAdding: .day, value: -13, to: sunday!)!
        }
        
        var endOfLastTwoWeek: Date {
            let gregorian = Calendar(identifier: .gregorian)
            let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self))
            return gregorian.date(byAdding: .day, value: -6, to: sunday!)!
        }
        
        var startOfLastThreeWeek:  Date {
            let gregorian = Calendar(identifier: .gregorian)
            let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self))
            return gregorian.date(byAdding: .day, value: -20, to: sunday!)!
        }
        
        var endOfLastThreeWeek: Date {
            let gregorian = Calendar(identifier: .gregorian)
            let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self))
            return gregorian.date(byAdding: .day, value: -13, to: sunday!)!
        }
        

}





