
let app = XCUIApplication()
let mindfulMinutesButton = app/*@START_MENU_TOKEN@*/.buttons["Mindful Minutes"]/*[[".segmentedControls.buttons[\"Mindful Minutes\"]",".buttons[\"Mindful Minutes\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
mindfulMinutesButton.tap()
mindfulMinutesButton.tap()
app/*@START_MENU_TOKEN@*/.buttons["STEPS TAKEN"]/*[[".segmentedControls.buttons[\"STEPS TAKEN\"]",".buttons[\"STEPS TAKEN\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
mindfulMinutesButton.tap()

let tabBarsQuery = app.tabBars
tabBarsQuery.buttons["MY WEEK SO FAR"].tap()
app.scrollViews.otherElements.buttons["Update"].tap()
tabBarsQuery.buttons["HOME"].tap()
app.buttons["CHECK"].tap()
app.alerts["Your Score This Week is:"].children(matching: .other).element.children(matching: .other).element.children(matching: .other).element(boundBy: 1).children(matching: .other).element(boundBy: 0).children(matching: .other).element.tap()
app.otherElements.containing(.alert, identifier:"Your Score This Week is:").children(matching: .other).element(boundBy: 0).tap()
app.children(matching: .window).element(boundBy: 0).children(matching: .other).element.children(matching: .other).element.children(matching: .other).element.children(matching: .other).element.children(matching: .other).element.children(matching: .other).element.children(matching: .other).element.children(matching: .button).element(boundBy: 1).tap()
app.navigationBars["wellwellwell3.Share"].buttons["Home"].tap()
//
//  wellwellwell3UITests.swift
//  wellwellwell3UITests
//
//  Created by LYM on 04/07/2019.
//  Copyright © 2019 LYM. All rights reserved.
//

import XCTest

class wellwellwell3UITests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

}
